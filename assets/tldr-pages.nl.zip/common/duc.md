# duc

> Een verzameling van tools voor het indexeren, inspecteren en visualiseren van schijfgebruik.
> Duc onderhoudt een database van geaccumuleerde groottes van directories van het bestandssysteem, waardoor je deze database kunt raadplegen of mooie grafieken kunt maken om te laten zien waar de data zich bevindt.
> Meer informatie: <http://duc.zevv.nl>.

- Indexeer de /usr directory en schrijf naar de standaard database locatie ~/.duc.db:

`duc index {{/usr}}`

- Toon alle bestanden en directories onder /usr/local en toon relatieve bestandsgroottes in een [g]rafiek:

`duc ls -Fg {{/usr/local}}`

- Toon alle bestanden en directories onder /usr/local recursief met behulp van boomweergave:

`duc ls -Fg -R {{/usr/local}}`

- Start de grafische interface om het bestandssysteem te verkennen met behulp van zonnestraalgrafieken:

`duc gui {{/usr}}`

- Start de ncurses console interface om het bestandssysteem te verkennen:

`duc ui {{/usr}}`

- Dump database-informatie:

`duc info`
